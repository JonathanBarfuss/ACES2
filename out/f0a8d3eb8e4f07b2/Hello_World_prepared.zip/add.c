#include <stdio.h>

/**
 * This is a student's assignment!
 * replacement should happen here:     aw:f0a8d3eb8e4f07b2c4fc7dd80f7cd859ea2cf65d04aea17a653d4d9359dcd696
 */

int add(int a, int b) {
    return a + b;
}

int main() {
    printf("Hello world!\n");
    printf("2 + 2 = %d\n", add(2, 2));
    return 0;
}

// replacement should also happen here:
// aw:f0a8d3eb8e4f07b2c4fc7dd80f7cd859ea2cf65d04aea17a653d4d9359dcd696