#include <stdio.h>

/**
 * This is a student's assignment!
 * replacement should happen here:     aw:90086cf083335a5a692b0e0a481948ba15a8f8a02cbd753b312aab5a9fa434b2
 */

int add(int a, int b) {
    return a + b;
}

int main() {
    printf("Hello world!\n");
    printf("2 + 2 = %d\n", add(2, 2));
    return 0;
}

// replacement should also happen here:
// aw:90086cf083335a5a692b0e0a481948ba15a8f8a02cbd753b312aab5a9fa434b2