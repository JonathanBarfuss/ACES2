#include <stdio.h>

/**
 * This is a student's assignment!
 * replacement should happen here:     aw:20691e0b31c58f61b09473db0b89db523a9d4efb154ecbd92f7ed05ae7ce5d48
 */

int add(int a, int b) {
    return a + b;
}

int main() {
    printf("Hello world!\n");
    printf("2 + 2 = %d\n", add(2, 2));
    return 0;
}

// replacement should also happen here:
// aw:20691e0b31c58f61b09473db0b89db523a9d4efb154ecbd92f7ed05ae7ce5d48