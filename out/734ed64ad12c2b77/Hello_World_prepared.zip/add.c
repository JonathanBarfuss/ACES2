#include <stdio.h>

/**
 * This is a student's assignment!
 * replacement should happen here:     aw:734ed64ad12c2b7790efa6b31918ef5b3d08bd4a393a1234d2b1b2a12c79ed46
 */

int add(int a, int b) {
    return a + b;
}

int main() {
    printf("Hello world!\n");
    printf("2 + 2 = %d\n", add(2, 2));
    return 0;
}

// replacement should also happen here:
// aw:734ed64ad12c2b7790efa6b31918ef5b3d08bd4a393a1234d2b1b2a12c79ed46