#include <stdio.h>

/**
 * This is a student's assignment!
 * replacement should happen here:     aw:40edb70deaafdbbaf320cb51067e4324ee2aab5f5c84e07d1ae2693303a49b53
 */

int add(int a, int b) {
    return a + b;
}

int main() {
    printf("Hello world!\n");
    printf("2 + 2 = %d\n", add(2, 2));
    return 0;
}

// replacement should also happen here:
// aw:40edb70deaafdbbaf320cb51067e4324ee2aab5f5c84e07d1ae2693303a49b53