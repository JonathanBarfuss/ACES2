#include <stdio.h>

/**
 * This is a student's assignment!
 * replacement should happen here:     aw:25b9bafccf76ac82a864c1e3056f744bc0a04074a8323a812032b0b674ed28ec
 */

int add(int a, int b) {
    return a + b;
}

int main() {
    printf("Hello world!\n");
    printf("2 + 2 = %d\n", add(2, 2));
    return 0;
}

// replacement should also happen here:
// aw:25b9bafccf76ac82a864c1e3056f744bc0a04074a8323a812032b0b674ed28ec