#include <stdio.h>

/**
 * This is a student's assignment!
 * replacement should happen here:     aw:51fdee5a4681fd16284e605582c1a4e32c7ea3c4593bb71317c05248ba30ab00
 */

int add(int a, int b) {
    return a + b;
}

int main() {
    printf("Hello world!\n");
    printf("2 + 2 = %d\n", add(2, 2));
    return 0;
}

// replacement should also happen here:
// aw:51fdee5a4681fd16284e605582c1a4e32c7ea3c4593bb71317c05248ba30ab00