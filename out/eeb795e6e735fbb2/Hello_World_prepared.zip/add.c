#include <stdio.h>

/**
 * This is a student's assignment!
 * replacement should happen here:     aw:eeb795e6e735fbb2b9958d51db426b489fbdea47d63a58547554bca6a981e454
 */

int add(int a, int b) {
    return a + b;
}

int main() {
    printf("Hello world!\n");
    printf("2 + 2 = %d\n", add(2, 2));
    return 0;
}

// replacement should also happen here:
// aw:eeb795e6e735fbb2b9958d51db426b489fbdea47d63a58547554bca6a981e454