#include <stdio.h>

/**
 * This is a student's assignment!
 * replacement should happen here:     aw:dc3de620c6caeecb3f2166de877d6304535d92f316502bd42be702791d136a37
 */

int add(int a, int b) {
    return a + b;
}

int main() {
    printf("Hello world!\n");
    printf("2 + 2 = %d\n", add(2, 2));
    return 0;
}

// replacement should also happen here:
// aw:dc3de620c6caeecb3f2166de877d6304535d92f316502bd42be702791d136a37