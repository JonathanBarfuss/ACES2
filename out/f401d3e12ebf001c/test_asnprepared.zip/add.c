#include <stdio.h>

/**
 * This is a student's assignment!
 * replacement should happen here:     aw:f401d3e12ebf001c923aac6b6a69d2f032d2f624f7ba74cbb9d82ef6da042a2a
 */

int add(int a, int b) {
    return a + b;
}

int main() {
    printf("Hello world!\n");
    printf("2 + 2 = %d\n", add(2, 2));
    return 0;
}

// replacement should also happen here:
// aw:f401d3e12ebf001c923aac6b6a69d2f032d2f624f7ba74cbb9d82ef6da042a2a