#include <stdio.h>

/**
 * This is a student's assignment!
 * replacement should happen here:     aw:1a1a7cafdb9fc2ae70ec0f33655aba1eb7ee2c731d49bbcf96ad65bd6088d91c
 */

int add(int a, int b) {
    return a + b;
}

int main() {
    printf("Hello world!\n");
    printf("2 + 2 = %d\n", add(2, 2));
    return 0;
}

// replacement should also happen here:
// aw:1a1a7cafdb9fc2ae70ec0f33655aba1eb7ee2c731d49bbcf96ad65bd6088d91c