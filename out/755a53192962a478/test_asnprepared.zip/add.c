#include <stdio.h>

/**
 * This is a student's assignment!
 * replacement should happen here:     aw:755a53192962a478b7d65f6d73fc0616ba3bb5c8bf28798640000f8ec62fab24
 */

int add(int a, int b) {
    return a + b;
}

int main() {
    printf("Hello world!\n");
    printf("2 + 2 = %d\n", add(2, 2));
    return 0;
}

// replacement should also happen here:
// aw:755a53192962a478b7d65f6d73fc0616ba3bb5c8bf28798640000f8ec62fab24