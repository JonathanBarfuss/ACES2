#include <stdio.h>

/**
 * This is a student's assignment!
 * replacement should happen here:     aw:576e9b764f653c50afa9af9095b03149d0d0c8b383fef70700ae8a153cdc9908
 */

int add(int a, int b) {
    return a + b;
}

int main() {
    printf("Hello world!\n");
    printf("2 + 2 = %d\n", add(2, 2));
    return 0;
}

// replacement should also happen here:
// aw:576e9b764f653c50afa9af9095b03149d0d0c8b383fef70700ae8a153cdc9908