#include <stdio.h>

/**
 * This is a student's assignment!
 * replacement should happen here:     aw:13b3d39de4e962f9c37d68abf23685351ede42e16100467fd366530047836db3
 */

int add(int a, int b) {
    return a + b;
}

int main() {
    printf("Hello world!\n");
    printf("2 + 2 = %d\n", add(2, 2));
    return 0;
}

// replacement should also happen here:
// aw:13b3d39de4e962f9c37d68abf23685351ede42e16100467fd366530047836db3