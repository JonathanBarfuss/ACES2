#include <stdio.h>

/**
 * This is a student's assignment!
 * replacement should happen here:     aw:c31d715fc98503ad5e118f561a7283269049754327bee59abf18fd908980e12f
 */

int add(int a, int b) {
    return a + b;
}

int main() {
    printf("Hello world!\n");
    printf("2 + 2 = %d\n", add(2, 2));
    return 0;
}

// replacement should also happen here:
// aw:c31d715fc98503ad5e118f561a7283269049754327bee59abf18fd908980e12f