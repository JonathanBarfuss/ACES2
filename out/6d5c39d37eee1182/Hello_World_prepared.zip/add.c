#include <stdio.h>

/**
 * This is a student's assignment!
 * replacement should happen here:     aw:6d5c39d37eee11829cfe6d67c6bc48188608ca3a646c5cc6397538701d943901
 */

int add(int a, int b) {
    return a + b;
}

int main() {
    printf("Hello world!\n");
    printf("2 + 2 = %d\n", add(2, 2));
    return 0;
}

// replacement should also happen here:
// aw:6d5c39d37eee11829cfe6d67c6bc48188608ca3a646c5cc6397538701d943901