#include <stdio.h>

/**
 * This is a student's assignment!
 * replacement should happen here:     aw:465a9eddf1d4dd1d806da9e78d0774977a7d4d71c33a751712273fd58616ea15
 */

int add(int a, int b) {
    return a + b;
}

int main() {
    printf("Hello world!\n");
    printf("2 + 2 = %d\n", add(2, 2));
    return 0;
}

// replacement should also happen here:
// aw:465a9eddf1d4dd1d806da9e78d0774977a7d4d71c33a751712273fd58616ea15