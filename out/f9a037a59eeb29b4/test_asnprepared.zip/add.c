#include <stdio.h>

/**
 * This is a student's assignment!
 * replacement should happen here:     aw:f9a037a59eeb29b4b77722f3d4b379e970aa44599e4fdf2ee498a2143f84a9da
 */

int add(int a, int b) {
    return a + b;
}

int main() {
    printf("Hello world!\n");
    printf("2 + 2 = %d\n", add(2, 2));
    return 0;
}

// replacement should also happen here:
// aw:f9a037a59eeb29b4b77722f3d4b379e970aa44599e4fdf2ee498a2143f84a9da