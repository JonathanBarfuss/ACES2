#include <stdio.h>

/**
 * This is a student's assignment!
 * replacement should happen here:     aw:f7f6b7593d7f1e78fd576e0989c9ac9c878b7854d22a707a41ba5af4c0a5d687
 */

int add(int a, int b) {
    return a + b;
}

int main() {
    printf("Hello world!\n");
    printf("2 + 2 = %d\n", add(2, 2));
    return 0;
}

// replacement should also happen here:
// aw:f7f6b7593d7f1e78fd576e0989c9ac9c878b7854d22a707a41ba5af4c0a5d687